<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">	
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
        
        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-body">
                            <table class="table">
                                <thead>                     
                                    <tr>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', 'ID'));?></th>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name',));?></th>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('subject'));?></th>
                                        <th>Body</th>
                                        <th>Action</th>
                                    </tr>					    
                                </thead>

                                <tbody>
                                    <?php if(count($emailTemplateList)): ?>
                                        <?php $__currentLoopData = $emailTemplateList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emailTemplate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($emailTemplate->id); ?></td>
                                                <td><?php echo e(!empty($emailTemplate->type) ? $emailTemplate->type : \Config::get('constants.EmptyNotation')); ?></td>
                                                <td><?php echo e(!empty($emailTemplate->subject) ? $emailTemplate->subject : \Config::get('constants.EmptyNotation')); ?></td>
                                                <td><?php echo e(!empty($emailTemplate->body) ? str_limit(strip_tags(html_entity_decode($emailTemplate->body)), $limit = 50, $end = '...') : \Config::get('constants.EmptyNotation')); ?></td>
                                                <td class="action-btn">
                                                    <?php echo e(Form::open(['method'=>'GET', 'route'=>['email-templates.edit', \Crypt::encryptString($emailTemplate->id)]])); ?>

                                                        <?php echo e(Form::button('', array('type'=>'submit', 'class'=>'fa fa-edit text-success', 'title'=>'Edit Email Template'))); ?>

                                                    <?php echo e(Form::close()); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <td colspan="4" class="error-msg"><?php echo e(__('messages.NotFound.EmailTemplate')); ?></td>
                                    <?php endif; ?>                                     
                                </tbody>
                            </table>
                            
                            <?php if(count($emailTemplateList)): ?>    
                                <div class="col-lg-12">
                                    <div class="pagination"><?php echo $emailTemplateList->appends(request()->query())->links(); ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.js.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/email_templates/index.blade.php ENDPATH**/ ?>