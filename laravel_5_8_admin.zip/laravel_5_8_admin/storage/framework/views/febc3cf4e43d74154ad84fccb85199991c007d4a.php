<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>        
            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($subTitle); ?></h3>
                        </div>
                        
                        <?php echo e(Form::open(array('method'=>'POST', 'id'=>'changePasswordForm'))); ?>

                            <div class="box-body">
                                <div class="form-group">
                                    <label>Current Password</label>
                                    <?php echo e(Form::password('current_password', array('class'=>'form-control required'))); ?>

                                </div>
                                
                                <div class="form-group">
                                    <label>New Password</label>
                                    <?php echo e(Form::password('password', array('class'=>'form-control required', 'id'=>'password', 'minlength'=>'8', 'maxlength'=>'15'))); ?>

                                </div>
                                
                                <div class="form-group">
                                    <label>Confirm New Password</label>
                                    <?php echo e(Form::password('password_confirmation', array('class'=>'form-control required', 'data-rule-equalTo'=>'#password'))); ?> 
                                </div>                            

                                <div class="form-group">
                                    <?php echo e(Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat'))); ?>

                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#changePasswordForm').validate();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/admin/change_password.blade.php ENDPATH**/ ?>