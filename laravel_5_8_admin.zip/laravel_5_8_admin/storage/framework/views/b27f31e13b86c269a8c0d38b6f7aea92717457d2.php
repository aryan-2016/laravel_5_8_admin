<?php $__env->startSection('content'); ?>
    <div class="login-box">
        <div class="login-logo">          
            <a href="<?php echo e(url('/admin')); ?>">
                
                <?php echo e(config('SiteName')); ?>

            </a>            
        </div>

        <div class="login-box-body">
            <p class="login-box-msg">Sign in</p>
            
            <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo e(Form::open(array('class'=>'login-form', 'id'=>'loginForm', 'autocomplete' => 'off', 'method'=>'POST'))); ?>	
                <div class="form-group has-feedback">
                    <?php echo e(Form::text('email', null, array('class'=>'form-control email required', 'placeholder'=>'Email', 'autofocus'))); ?>

                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
            
                <div class="form-group has-feedback">
                    <?php echo e(Form::password('password', array('class'=>'form-control required', 'placeholder'=>'Password'))); ?> 
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
            
                <?php if($displayRecaptcha): ?>
                    <div class="form-group has-feedback">
                        <div class="g-recaptcha" data-sitekey="<?php echo e(CommonHelper::fetchGlobalSettingValueByName('GoogleRecaptchaSiteKey')); ?>"></div>
                        <span id="g-recaptcha-error" style="display:none;" for="g-recaptcha"><?php echo e(__('messages.VerifyCaptcha')); ?></span>
                    </div>
                <?php endif; ?>
            
                <div class="row">
                    <div class="col-xs-12">
                        <?php echo e(Form::submit('Sign In', array('class'=>'btn btn-primary btn-block btn-flat', 'id'=>'loginBtn'))); ?> 
                    </div>
                </div>
            <?php echo e(Form::close()); ?>

            
            <a href="<?php echo e(url('/admin/forgot-password')); ?>">I forgot my password</a>
        </div>
    </div>

    <script src='https://www.google.com/recaptcha/api.js'></script>

    <script>
        $(function () {
            $("#loginForm").validate();

            <?php if($displayRecaptcha): ?>
                $("#loginBtn").click( function(e){
                    var isCaptchaChecked = (grecaptcha && grecaptcha.getResponse().length !== 0);

                    if(!isCaptchaChecked)
                    {
                        e.preventDefault(e);
                        $('#g-recaptcha-error').show();
                    }
                });
            <?php endif; ?>
        });
    </script>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/admin/login.blade.php ENDPATH**/ ?>