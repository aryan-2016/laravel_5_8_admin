<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox showhidesearch boxShadow">
                                
                                <?php echo e(Form::open(array('method'=>'get'))); ?>

                                    <div class="col-lg-3">                                        
                                        <?php echo e(Form::text('search', app('request')->input('search'), ['placeholder'=>'Email or Name', 'class'=>'form-control'])); ?>					
                                    </div>

                                    <div class="col-lg-4">	
                                        <?php echo e(Form::submit('Search', ['class'=>'btn btn-primary'])); ?>

                                        <a href="<?php echo e(url('/admin/users')); ?>" class="btn btn-default">Reset</a>
                                    </div>						
                                <?php echo e(Form::close()); ?>

                            </div>	
                        </div>
                    
                        <div class="box-body">                            
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', "ID"));?></th>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('fullname', 'Full Name'));?></th>                                        
                                        <th>Contact Number</th>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('email'));?></th>
                                        <th>Joined Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php if(count($users)): ?>
                                        <?php
                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                            $changeStatusTo = ['Active' => 'Deactivate', 'Inactive' => 'Activate'];
                                        ?>

                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->id); ?></td>
                                                <td><?php echo e(!empty($user->fullname) ? $user->fullname : \Config::get('constants.EmptyNotation')); ?></td>
                                                <td><?php echo e(!empty($user->contact_number) ? $user->contact_number : \Config::get('constants.EmptyNotation')); ?></td>                                                
                                                <td title="<?php echo e($user->email); ?>"><?php echo e(!empty($user->email) ? str_limit($user->email, $limit = 25, $end = '...') : \Config::get('constants.EmptyNotation')); ?></td>
                                                <td><?php echo e($user->created_at); ?></td>
                                                <td data="<?php echo e(\Crypt::encryptString($user->id)); ?>" model="<?php echo e(\Crypt::encryptString('users')); ?>" class="change-status-confirm <?php echo e($user->status); ?>" title="Change Status"><span class="label <?php echo e($statusClasses[$user->status]); ?>" id="status-<?php echo e($user->id); ?>"><?php echo e($user->status); ?></span></td>
                                                <td class="action-btn">

                                                    <?php echo e(Form::open(['method'=>'GET', 'route'=>['users.edit', \Crypt::encryptString($user->id)]])); ?>

                                                        <?php echo e(Form::button('', array('type'=>'submit', 'class'=>'pull-left fa fa-edit text-success', 'title'=>'Edit User'))); ?>

                                                    <?php echo e(Form::close()); ?>


                                                    <?php echo Form::open(['method' => 'GET', 'route' => ['users.show', \Crypt::encryptString($user->id)]]); ?>

                                                    <?php echo Form::button('', array('type' => 'submit', 'class' => 'pull-left fa fa-eye text-primary', 'title' => 'View User')); ?>

                                                    <?php echo Form::close(); ?>


                                                    <?php echo e(Form::open(['method'=>'DELETE', 'route'=>['users.destroy', \Crypt::encryptString($user->id)]])); ?>

                                                        <?php echo e(Form::button('', array('type'=>'submit', 'class'=>'delete-confirm pull-left fa fa-trash text-danger', 'title'=>'Delete User'))); ?>

                                                    <?php echo e(Form::close()); ?> 

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr><td colspan="8" class="error-msg"><?php echo e(__('messages.NotFound.User')); ?></td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            
                            <?php if(count($users)): ?>    
                                <div class="col-lg-12">
                                    <div class="pagination"> 
                                        <?php echo $users->appends($_GET)->links(); ?> 
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.js.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/users/index.blade.php ENDPATH**/ ?>