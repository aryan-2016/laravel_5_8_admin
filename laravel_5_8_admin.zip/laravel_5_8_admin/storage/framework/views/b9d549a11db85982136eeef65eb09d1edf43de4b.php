<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box box-primary">
                        <?php echo e(Form::model($mailingAddressesSettings, array('route' => array('update-mailing-addresses-settings', \Crypt::encryptString(!empty($mailingAddressesSettings) ? $mailingAddressesSettings->id : '')), 'method' => 'POST', 'id'=>'mailingAddressesSettingForm'))); ?>

                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Admin Email Id</label>
                                            <?php echo e(Form::text('admin_email_id', null, array('class'=>'form-control email required'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Support Email Id</label>
                                            <?php echo e(Form::text('support_email_id', null, array('class'=>'form-control email required'))); ?>

                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>No Reply Email Id</label>
                                            <?php echo e(Form::text('no_reply_email_id', null, array('class'=>'form-control email required'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Contact Us Email Id</label>
                                            <?php echo e(Form::text('contact_us_email_id', null, array('class'=>'form-control email required'))); ?>

                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4">
                                        <?php echo e(Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat'))); ?>

                                    </div> 
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>                        
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#mailingAddressesSettingForm').validate();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/site_settings/mailing_addresses_settings.blade.php ENDPATH**/ ?>