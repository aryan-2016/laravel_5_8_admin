<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title><?php echo e(config('SiteName')); ?>: Admin</title>
        
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <link href="<?php echo e(asset('/css/admin/bootstrap.min.css')); ?>" rel="stylesheet">	
        <link href="<?php echo e(asset('/css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/admin.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/skins/skins.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/developer.css')); ?>" rel="stylesheet">

        <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/admin/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/admin/adminlte.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/jquery.validate.js')); ?>"></script>
    </head>
    <body class="hold-transition login-page">
        <?php echo $__env->yieldContent('content'); ?>
    </body> 
</html><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/layout/admin_login.blade.php ENDPATH**/ ?>