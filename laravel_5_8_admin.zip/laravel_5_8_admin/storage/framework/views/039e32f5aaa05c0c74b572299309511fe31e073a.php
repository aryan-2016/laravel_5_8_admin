<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($subTitle); ?></h3>
                        </div>
                        
                        <?php if(!empty($user)): ?>
                            <?php echo e(Form::model($user, array('route'=>array('users.update', \Crypt::encryptString($user->id)), 'method'=>'PUT', 'files'=>true, 'id'=>'userForm'))); ?>

                        <?php else: ?>
                            <?php echo e(Form::open(array('url'=>'/admin/users', 'id'=>'userForm', 'files'=>true))); ?>

                        <?php endif; ?>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            <?php echo e(Form::text('first_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Last Name</label>
                                            <?php echo e(Form::text('last_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>                                    
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        
                                    </div>                              

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            <?php echo e(Form::text('email', null, array('class'=>'form-control required email', 'id'=>'emailId', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div> 
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Contact Number (Optional)</label>
                                            <?php echo e(Form::text('contact_number', null, array('class'=>'form-control phoneUS', 'minlength'=>'8', 'maxlength'=>'20'))); ?> 
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <?php echo e(Form::Select('status', $status, null, ['placeholder'=>' - select - ', 'class'=>'form-control required'])); ?>

                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <label>Image <small>(Optional)</small></label>
                                        
                                        <div class="image-upload">
                                            <div class="file-label text-center">Browse...</div>
                                            <?php echo e(Form::file('image', ['id'=>'image'])); ?>

                                        </div>

                                        <span class="img-error error"></span>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                        <?php if(!empty($user->image) && Storage::disk('public')->exists('users/' . $user->image)): ?>
                                            <i class="fa fa-remove delete-image"></i>

                                            <a href="<?php echo e(asset('storage/app/public/users/' . $user->image)); ?>" class="gallery_popup" data-fancybox-group="gallery">
                                                <?php echo e(Html::image(Storage::url('app/public/users/' . $user->image), 'image', array('id'=>'imagePreview', 'title'=>'Image Preview', 'class'=>'img_prvew img_prvew_height'))); ?>

                                            </a>
                                            
                                            <?php echo e(Form::hidden('delete_image', null, ['id'=>'deleteImage'])); ?>

                                        <?php else: ?>
                                            <i class="fa fa-remove delete-image" style="display:none;"></i>

                                            <a href="<?php echo e(asset(\Config::get('constants.NoImageIcon'))); ?>" class="gallery_popup" data-fancybox-group="gallery">
                                                <?php echo e(Html::image(asset(\Config::get('constants.NoImageIcon')), 'image', array('id'=>'imagePreview', 'title'=>'Image Preview', 'class'=>'img_prvew img_prvew_height'))); ?>

                                            </a>
                                        <?php endif; ?> 
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        <?php echo e(Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat'))); ?>

                                    </div>
                                </div>
                            </div>    
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.js.custom_validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.elements.js.image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <?php echo $__env->make('admin.elements.js.fancybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script>
        $(document).ready(function(){            
            $('#userForm').validate({
                rules: {
                    email: {
                        required: true,
                        remote: {
                            url: APP_URL + "/admin/check-email-availability",
                            type: "post",
                            data: {
                                _token: _token,
                                email: $("input[email='email']").val(),
                                userId: "<?php echo e(\Crypt::encryptString($user->id)); ?>",
                                roleId: "<?php echo e(\Crypt::encryptString($user->role_id)); ?>"
                            }
                        }
                    }
                },
                messages: {
                    email: {
                        required: 'Email is required.',
                        email: 'Please enter a valid email address.',
                        remote: 'Email already taken.'
                    }
                },
                submitHandler: function(form, submitFlag) {
                    var submitFlag = true;

                    if($('.img-error').html() !='')
                    {						
                        submitFlag = false;
                    }                                        
                    else
                    {
                        $('.img-error').html();
                    }

                    if(submitFlag) 
                        form.submit();
                }   
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>