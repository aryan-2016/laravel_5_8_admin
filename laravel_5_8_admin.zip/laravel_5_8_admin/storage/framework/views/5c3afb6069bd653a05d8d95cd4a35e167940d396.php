<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box box-primary">
                        <?php echo e(Form::model($smtpSettings, array('route' => array('update-smtp-setting', \Crypt::encryptString(!empty($smtpSettings) ? $smtpSettings->id : '')), 'method' => 'POST', 'id'=>'smtpSettingForm'))); ?>

                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Driver</label>
                                            <?php echo e(Form::text('driver', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Host</label>
                                            <?php echo e(Form::text('host', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191'))); ?>

                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Port</label>
                                            <?php echo e(Form::text('port', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>User Name</label>
                                            <?php echo e(Form::text('username', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191'))); ?>

                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <?php echo e(Form::text('password', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Encryption</label>
                                            <?php echo e(Form::text('encryption', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div> 
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Mail From Email Address</label>
                                            <?php echo e(Form::text('mail_from_email_address', null, array('class'=>'form-control required email', 'minlength'=>'5', 'maxlength'=>'191'))); ?>

                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Mail From Name</label>
                                            <?php echo e(Form::text('mail_from_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191'))); ?>

                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4">
                                        <?php echo e(Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat'))); ?>

                                    </div> 
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>                        
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#smtpSettingForm').validate();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/site_settings/smtp_settings.blade.php ENDPATH**/ ?>