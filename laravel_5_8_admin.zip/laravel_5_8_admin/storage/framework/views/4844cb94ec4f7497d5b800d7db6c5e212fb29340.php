<div class="box-body">
<div class="table-responsive">
<?php if(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'farmer' || app('request')->input('report_type') == 'user')): ?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Registered On</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>

        <?php if(!empty($dataList) && is_object($dataList) && count($dataList) > 0): ?>

            <?php
                $farmerOrUserCount = 0;
            ?>
            <?php $__currentLoopData = $dataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('farmers.show', \Crypt::encryptString($data->id))); ?>" title='View Farmer'>
                            <?php echo e($data->id); ?>

                        </a>
                    </td>
                    <td><?php echo e(!empty($data->fullname) ? $data->fullname : \Config::get('constants.EmptyNotation')); ?></td>
                    <td><?php echo e(!empty($data->email) ? $data->email : \Config::get('constants.EmptyNotation')); ?></td>
                    <td><?php echo e($data->created_at); ?></td>
                    <td>
                        <?php
                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                        ?>
                        
                        <span class="label <?php echo e($statusClasses[$data->status]); ?>">
                            <?php echo e(ucwords(str_replace('-', ' ', $data->status))); ?>

                        </span>
                    </td>
                </tr>
                <?php
                $farmerOrUserCount++;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        <?php else: ?>
            <?php if(!empty(app('request')->input('report_type')) && app('request')->input('report_type') == 'farmer'): ?>
            <tr><td colspan="6" class="error-msg"><?php echo e(__('messages.NotFound.Farmer')); ?></td></tr>
            <?php elseif(!empty(app('request')->input('report_type')) && app('request')->input('report_type') == 'user'): ?>
            <tr><td colspan="6" class="error-msg"><?php echo e(__('messages.NotFound.User')); ?></td></tr>
            <?php endif; ?>
        <?php endif; ?>
                                            
    </tbody>
</table>

<?php elseif(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'payment')): ?>

<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Farmer Name</th>
            <th>Price</th>
            <th>Transaction ID</th>
            <th>Date Time</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>
    <?php if(!empty($paymentList) && is_object($paymentList) && count($paymentList) > 0): ?>
    <?php
        $statusClasses = ['Approve' => 'label-success', 'Reject' => 'label-danger', 'Pending' => 'label-primary'];
        $changeStatusTo = ['Pending' => 'Approve', 'Approve' => 'Reject', 'Reject' => 'Approve'];
        $total = 0;
            
    ?>

    <?php $__currentLoopData = $paymentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td>
            <a href="<?php echo e(route('payments.show', \Crypt::encryptString($payment->id))); ?>" title='View Payment'>
                <?php echo e(!empty($payment->id) ? $payment->id : \Config::get('constants.EmptyNotation')); ?>

            </a>
        </td>
        <td><?php echo e(!empty($payment->User->full_name) ? $payment->User->full_name : \Config::get('constants.EmptyNotation')); ?></td>
        <td><?php echo e(!empty($payment->pay_amount) ? $payment->pay_amount : \Config::get('constants.EmptyNotation')); ?></td>
        <td><?php echo e(!empty($payment->transaction_id) ? $payment->transaction_id : \Config::get('constants.EmptyNotation')); ?></td>
        <td><?php echo e($payment->created_at); ?></td>
        <td>
            <?php
                $statusClasses = ['Complete' => 'label-success', 'Failed' => 'label-danger', 'Pending' => 'label-primary'];
            ?>
            
            <span class="label <?php echo e($statusClasses[$payment->status]); ?>">
                <?php echo e(ucwords(str_replace('-', ' ', $payment->status))); ?>

            </span>
        </td>
    </tr>

        <?php
        $total = $total+$payment->pay_amount;
        ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>
        <tr><td colspan="6" class="error-msg"><?php echo e(__('messages.NotFound.Payment')); ?></td></tr>
    <?php endif; ?>
                                            
    </tbody>
</table>

<?php else: ?>
    <center><span colspan="6" class="error-msg"><?php echo e(__('messages.NotFound.ReportType')); ?></span></center>
<?php endif; ?>
</div>
</div>


<div class="box-footer clearfix">

<div class="col-md-9">

<?php if(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'farmer' || app('request')->input('report_type') == 'user') && !empty($dataList) && count($dataList) > 0): ?>    
<div class="pagination"> 
    <?php echo $dataList->appends($_GET)->links(); ?> 
</div>
<?php elseif(!empty($paymentList) && count($paymentList) > 0): ?>
<div class="pagination"> 
    <?php echo $paymentList->appends($_GET)->links(); ?> 
</div>
<?php endif; ?>
</div>

 <div class="col-md-3">
<?php if(!empty($farmerOrUserCount)): ?>
<label class="btn-sm btn-primary pull-right"><b><?php echo e(!empty($label) ? $label : ''); ?>:</b> <?php echo e(!empty($farmerOrUserCount) ? $farmerOrUserCount : ''); ?></label>
<?php elseif(!empty($total)): ?>
<label class="btn-sm btn-primary pull-right"><b>Total Revenue Generated: </b> <?php echo e(!empty($total) ? $total : ''); ?></label>
<?php endif; ?>
</div>

</div>

<style>ul.pagination{margin: auto !important;}</style>



<?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/elements/report.blade.php ENDPATH**/ ?>