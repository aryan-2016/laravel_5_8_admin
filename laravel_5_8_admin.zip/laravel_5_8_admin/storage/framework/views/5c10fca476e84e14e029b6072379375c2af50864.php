<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title><?php echo e(config('SiteName')); ?>: Admin</title>
        
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <?php echo e(Html::favicon( asset('/favicon.ico') )); ?>

        
        <link href="<?php echo e(asset('/css/admin/bootstrap.min.css')); ?>" rel="stylesheet">	
        <link href="<?php echo e(asset('/css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/admin.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/skins/skins.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/css/admin/developer.css')); ?>" rel="stylesheet">
        
        <script src="<?php echo e(asset('/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/admin/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/admin/adminlte.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/jquery.validate.js')); ?>"></script>
        
        <script>
            var APP_URL = "<?php echo e(config('app.url')); ?>";

            var _token = "<?php echo e(csrf_token()); ?>";
        </script>        
    </head>
    
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">    
            <?php echo $__env->make('admin.elements.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('admin.elements.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>            
            
            <?php echo $__env->make('admin.elements.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/layout/admin_inner_page.blade.php ENDPATH**/ ?>