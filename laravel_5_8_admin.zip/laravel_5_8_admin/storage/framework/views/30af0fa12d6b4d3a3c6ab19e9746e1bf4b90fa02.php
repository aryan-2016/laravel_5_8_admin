<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-block text-center">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>

    <?php (Session::forget('success')); ?>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger text-center">
        <button type="button" class="close" data-dismiss="alert">×</button>	
        <strong><?php echo e(Session::get('error')); ?></strong>
    </div>

    <?php (Session::forget('error')); ?>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
    <div class="alert alert-warning alert-block text-center">
        <button type="button" class="close" data-dismiss="alert">×</button>	
        <strong><?php echo e(Session::get('warning')); ?></strong>
    </div>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <div class="alert alert-info alert-block text-center">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e(Session::get('info')); ?></strong>
    </div>
<?php endif; ?>

<?php if(!empty($errors) && $errors->any()): ?>
    <div class="alert alert-danger text-center">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php if(count($errors)): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php endif; ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/flash_message.blade.php ENDPATH**/ ?>