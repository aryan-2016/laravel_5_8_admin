<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('name', 'Name'));?></th>                                        
                                        <th>Value</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php if(count($globalSettings)): ?>                                    
                                        <?php $__currentLoopData = $globalSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $globalSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="<?php echo e(\Crypt::encryptString($globalSetting->id)); ?>">
                                                <td><?php echo e(!empty($globalSetting->name) ? $globalSetting->name : \Config::get('constants.EmptyNotation')); ?></td>                                                
                                                <td style='width:70%;'>
                                                    <span class="editSpan setting-value"><?php echo e(!empty($globalSetting->value) ? $globalSetting->value : \Config::get('constants.EmptyNotation')); ?></span>
                                                    <input class="editInput setting-value" type="text" name="value" value="<?php echo e($globalSetting->value); ?>" style="display: none;">
                                                </td>
                                                <td>
                                                    <?php echo Form::button('', array('type' => 'button', 'class' => 'pull-left fa fa-edit text-success editBtn', 'title' => 'Edit Global Setting')); ?>

                                                    <?php echo Form::button('', array('type' => 'button', 'class' => 'pull-left fa fa-floppy-o saveBtn', 'title' => 'Save Global Setting', 'style' => 'display: none;')); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                    <?php else: ?>
                                        <tr><td colspan="4" class="error-msg"><?php echo e(\Config::get('flash_msg.NoRecordFound')); ?></td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.common.bootstrap_alert_model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function () {
            $('.editBtn').on('click',function(){
                //hide edit span
                $(this).closest("tr").find(".editSpan").hide();

                //show edit input
                $(this).closest("tr").find(".editInput").show().css({"width": "90%"});

                //hide edit button
                $(this).closest("tr").find(".editBtn").hide();

                //show save button
                $(this).closest("tr").find(".saveBtn").show();
            });
            
            $('.saveBtn').on('click',function(){
                var trObj = $(this).closest("tr");
                var ID = $(this).closest("tr").attr('id');
                var value = $(this).closest("tr").find(".editInput.setting-value").val();
                
                $.ajax({
                    type: 'POST',
                    url: APP_URL + "/admin/update-global-setting/" + ID,
                    dataType: "json",
                    data: {
                        _token: _token,
                        value: value
                    }
                })
                .done(function(response){
                    if(response.success){
                        trObj.find(".editSpan.setting-value").text(response.data.value);

                        trObj.find(".editInput.setting-value").text(response.data.value);

                        trObj.find(".editInput").hide();
                        trObj.find(".saveBtn").hide();
                        trObj.find(".editSpan").show();
                        trObj.find(".editBtn").show();

                        alertModel(response.message, 'success');
                    }
                    else{
                        alertModel(response.message, 'error');
                    }
                })
                .fail(function(jqXHR, textStatus) {
                    alertModel("<?php echo e(__('messages.SomethingWentWrong')); ?>", 'error');
                });
            });
        });
    </script>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/site_settings/global_settings.blade.php ENDPATH**/ ?>