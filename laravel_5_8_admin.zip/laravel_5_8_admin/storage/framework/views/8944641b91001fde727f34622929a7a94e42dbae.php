<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    &copy; <?php echo e(date('Y')); ?> <strong><?php echo e(config('SiteName')); ?>.</strong> All rights reserved.
</footer>
<?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/elements/common/footer.blade.php ENDPATH**/ ?>