<?php echo Html::script('/public/plugins/fancybox/jquery.fancybox.js'); ?>

<?php echo Html::style('/public/plugins/fancybox/jquery.fancybox.css'); ?>


<script>
    $(document).ready(function () {
        $(".gallery_popup").fancybox({
            fitToView : true,
            loop: false,
            wrapCSS : 'popup_wrapp' // add a class selector to the fancybox wrap
        });
    });
</script>
<?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/elements/js/fancybox.blade.php ENDPATH**/ ?>