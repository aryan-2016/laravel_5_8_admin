<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox boxShadow">
                                <?php echo e(Form::open(array('method'=>'get', 'id' => 'reportForm'))); ?>                                    
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class='input-group date' id='start_date'>
                                                <?php echo e(Form::text('start_date', app('request')->input('start_date'), array('placeholder'=>'Start Date', 'class'=>'form-control required', 'readonly'=>'readonly'))); ?> 
                                                <span class="input-group-addon">
                                                    <span class="fa fa-calendar"></span>
                                                </span>
                                            </div>                                                                               
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class='input-group date' id='end_date'>
                                                <?php echo e(Form::text('end_date', app('request')->input('end_date'), array('placeholder'=>'End Date', 'class'=>'form-control', 'readonly'=>'readonly'))); ?> 
                                                <span class="input-group-addon">
                                                    <span class="fa fa-calendar"></span>
                                                </span>
                                            </div>                                        
                                        </div>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <?php echo e(Form::Select('report_type', ['' => '- Report For -', 'farmer' => 'Farmer', 'user'=> 'User', 'payment' => 'Payment'], app('request')->input('report_type'), ['class'=>'form-control required'])); ?>

                                        </div>
                                    </div>    

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <?php echo e(Form::submit('Generate Reports', ['class'=>'btn btn-primary'])); ?>

                                            <a href="<?php echo e(url('/admin/reports')); ?>" class="btn btn-default">Reset</a>
                                        </div>
                                    </div>						
                                <?php echo e(Form::close()); ?>

                            </div>	
                        </div>
                        
                        <div id="reportDiv">
                            <?php echo $__env->make('admin.elements.report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                       
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.common.bootstrap_alert_model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo e(Html::style('/public/plugins/hierarchy-select/assets/pygments.css')); ?>

    <?php echo e(Html::style('/public/plugins/hierarchy-select/dist/hierarchy-select.min.css')); ?>


    <?php echo e(Html::script('/public/plugins/hierarchy-select/dist/hierarchy-select.min.js')); ?>


    <?php echo Html::script('/public/plugins/bootstrap-datetimepicker/src/js/moment-2.18.1.min.js');; ?>

    <?php echo Html::script('/public/plugins/bootstrap-datetimepicker/src/js/bootstrap-datetimepicker.js');; ?>

    <?php echo Html::style('/public/plugins/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css'); ?>


    <script>
        $(document).ready(function () {
            $('#reportForm').validate();
        });

        $(document).ready(function () {
            $('#start_date, #end_date').datetimepicker({
                format: 'YYYY-MM-DD',
                maxDate: moment(),
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down"
                },
                useCurrent: false,
                ignoreReadonly: true
            });
            
            $('#start_date').datetimepicker().on('dp.change', function (e) {
                var incrementDay = moment(new Date(e.date));
                
                $('#end_date').data('DateTimePicker').minDate(incrementDay);
                $(this).data("DateTimePicker").hide();

                dateDifference();
            });

            $('#end_date').datetimepicker().on('dp.change', function (e) {
                var decrementDay = moment(new Date(e.date));
                
                $('#start_date').data('DateTimePicker').maxDate(decrementDay);
                $(this).data("DateTimePicker").hide();

                dateDifference();
            });
        });

        function dateDifference()
        {
            var startDate = $('#start_date').data("DateTimePicker").date();
            var endDate = $('#end_date').data("DateTimePicker").date();
            var timeDiff = 0;

            if(endDate)
            {
                timeDiff = (endDate - startDate) / 1000;
            }

            var dateDiff = Math.floor(timeDiff / (60 * 60 * 24));

            if(dateDiff < 0)
            {
                alertModel("<?php echo e(__('messages.Js.EndDateShouldGreaterOrEqual')); ?>");

                return false;
            }

            return true;
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>