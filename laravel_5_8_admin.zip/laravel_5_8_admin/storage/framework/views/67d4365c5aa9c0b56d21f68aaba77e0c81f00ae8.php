<?php $__env->startSection('content'); ?>
    <section>
        <div class="bg-light">
            <div class="wrapper">
                <div class="breadcrumb_box">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/')); ?>">Home</a>
                        </li>
                    </ul>
                </div>
                
                <div class="clearfix"></div>
            </div>
          
            <div class="bg-white">
                <div class="wrapper text-center" style="padding:50px 0">
                    <h1 class="section-heading playfair-regular">
                        <span class="text-orange">Uh ho</span>, that page is not found
                    </h1>
                    
                    <!--<p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sem erat, mattis eu volutpat at, commodo a 
                    </p>-->
                    
                    <div class="form-element btn-group" style="line-height:48px; margin:20px 0  0">
                        <!--<a href="javascript:void(0)" class="btn green-border-btn bg-transparent radius-2 rb-bold text-uppercase">Back</a>-->
                        
                        <a href="<?php echo e(url('/')); ?>" class="btn green-btn radius-2 rb-bold text-uppercase">Home</a>
                    </div>
               </div>
            </div>
        </div>
        
        <div class="clearfix"></div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/errors/404.blade.php ENDPATH**/ ?>