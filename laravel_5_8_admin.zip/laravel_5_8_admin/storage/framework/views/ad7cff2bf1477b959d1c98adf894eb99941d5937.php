<header class="main-header">
    <a href="<?php echo e(url('/admin/dashboard')); ?>" class="logo">
    <?php
        if(!empty(config('SiteName'))):
            $siteName = implode('', array_map(function($v) { return $v[0]; }, explode(' ', config('SiteName'))));
        endif;
    ?>

        <span class="logo-mini">
            <b><?php echo e(!empty($siteName) ? $siteName : ''); ?></b>
        </span>
        
        <span class="logo-lg">
            <?php echo e(config('SiteName')); ?>

        </span>
    </a>
    
    <nav class="navbar navbar-static-top">
        <a href="javascript:void(0)" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown user user-menu">
                    <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" style="cursor: unset;color: #fff;">
                        <?php echo e(!empty(Auth::user()->first_name) ? Auth::user()->first_name : ''); ?>

                    </a>
                </li>
            </ul>
        </div>
    </nav>
</header><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/elements/common/header.blade.php ENDPATH**/ ?>