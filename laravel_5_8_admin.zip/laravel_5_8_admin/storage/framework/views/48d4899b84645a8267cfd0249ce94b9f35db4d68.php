<?php if(!empty($breadCrumData)): ?>
    <ol class="breadcrumb">
        <?php $__currentLoopData = $breadCrumData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($breadcrum['url'])): ?>
                <li>
                    <a href="<?php echo e($breadcrum['url']); ?>">
                        <i class="fa <?php echo e($breadcrum['breadFaClass']); ?>"></i> 
                        <?php echo e($breadcrum['text']); ?>

                    </a>
                </li>
            <?php else: ?>
                <li class="active"><?php echo e($breadcrum['text']); ?></li>			
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
<?php endif; ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/elements/common/breadcrumb.blade.php ENDPATH**/ ?>