<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($subTitle); ?></h3>
                        </div>
                        
                        <?php if(!empty($category)): ?>
                            <?php echo e(Form::model($category, array('route'=>array('categories.update', \Crypt::encryptString($category->id)), 'method'=>'PUT','id'=>'categoryForm'))); ?>

                        <?php else: ?>
                            <?php echo e(Form::open(array('url'=>'/admin/categories', 'id'=>'categoryForm'))); ?>

                        <?php endif; ?>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <?php echo e(Form::text('name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'255'))); ?>

                                        </div>
                                    </div>                                    
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <?php echo e(Form::Select('status', $status, null, ['placeholder'=>' - select - ', 'class'=>'form-control required'])); ?>

                                        </div>
                                    </div>
                                </div>                         
                    
                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        <?php echo e(Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat'))); ?>

                                    </div>
                                </div>
                            </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#categoryForm').validate();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/categories/edit.blade.php ENDPATH**/ ?>