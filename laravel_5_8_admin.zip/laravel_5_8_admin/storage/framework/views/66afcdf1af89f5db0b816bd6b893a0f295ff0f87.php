<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                <?php echo e($mainTitle); ?>

            </h1>

            <?php echo $__env->make('admin.elements.common.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"><?php echo e($subTitle); ?></h3>
                        </div>                                                
                            
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <td>Image</td>
                                        <td>
                                            <?php if(!empty($user->image) && Storage::disk('public')->has('users/' . $user->image)): ?>                                                        
                                                <a href="<?php echo e(asset('storage/app/public/users/' . $user->image)); ?>" class="gallery_popup" data-fancybox-group="gallery">
                                                    <?php echo e(Html::image(Storage::url('app/public/users/' . $user->image), 'image', ['class'=>'img_prvew img_prvew_height', 'title'=>'Image Preview'])); ?>

                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(asset(\Config::get('constants.NoImage50Icon'))); ?>" class="gallery_popup" data-fancybox-group="gallery">
                                                    <?php echo e(Html::image(asset(\Config::get('constants.NoImageIcon')), 'image', ['class'=>'img_prvew', 'title'=>'Image Preview'])); ?> 
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>First Name</td>
                                        <td><?php echo e(!empty($user->first_name) ? $user->first_name : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Last Name</td>
                                        <td><?php echo e(!empty($user->last_name) ? ucwords($user->last_name) : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Email</td>
                                        <td><?php echo e(!empty($user->email) ? $user->email : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Contact Number</td>
                                        <td><?php echo e(!empty($user->contact_number) ? $user->contact_number : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Status</td>
                                        <td><?php echo e(!empty($user->status) ? $user->status : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Joinded Date</td>
                                        <td><?php echo e(!empty($user->created_at) ? $user->created_at : \Config::get('constants.EmptyNotation')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php echo $__env->make('admin.elements.js.fancybox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin_inner_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lamppp/htdocs/laravel_5_8_admin/resources/views/admin/users/view.blade.php ENDPATH**/ ?>