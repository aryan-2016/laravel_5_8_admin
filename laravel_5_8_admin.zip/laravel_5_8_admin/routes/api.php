<?php

//use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

//-------------------Users----------------------

Route::post('login', 'API\UsersController@login');

Route::post('register', 'API\UsersController@register');

Route::get('activate-account/{token}', 'API\UsersController@activateUser');

Route::match(array('POST'), 'forgot-password', array(
    'uses' => 'API\UsersController@forgotPassword'
));

Route::match(array('GET', 'POST'), 'reset-password', array(
    'uses' => 'API\UsersController@resetPassword'
));

Route::group(['middleware' => ['auth:api']], function() {
    Route::get('logout', 'API\UsersController@logout');
    
    Route::match(array('GET', 'POST'), 'update-password', array(
        'uses' => 'API\UsersController@updatePassword'
    ));
    
    Route::match(array('GET', 'POST'), 'my-profile', array(
        'uses' => 'API\UsersController@myProfile'
    ));    

    Route::match(array('GET', 'POST'), 'update-profile', array(
        'uses' => 'API\UsersController@updateProfile'
    ));
});


//-------------------CmsPages--------------------

Route::match(array('GET'), 'page/{slug}', array(
    'uses' => 'API\CmsPagesController@page'
));
    
Route::match(array('GET', 'POST'), 'contact-us', array(
    'uses' => 'API\CmsPagesController@contactUs'
));