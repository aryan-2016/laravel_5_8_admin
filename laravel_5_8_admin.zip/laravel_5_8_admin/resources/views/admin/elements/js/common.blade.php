@include('admin.elements.common.bootstrap_alert_model')

<script src="{{ asset('/public/js/jquery.confirm.min.js') }}"></script>

<script>
    $(document).ready(function(){
        $(".delete-confirm").click(function(e) {
            e.preventDefault();
            confirmModel("{{ __('messages.Js.ConfirmDelete') }}", this);
        });
        
        $(".change-status-confirm").click(function(e) {
            var id = $(this).attr('data');
            var table = $(this).attr('model'); 
            
            e.preventDefault();
            
            statusChange("{{ __('messages.Js.ConfirmChangeStatus') }}", id, table );
        });
    });
    
    function confirmModel(msg, $this)
    {
        $.confirm({
            text: msg,
            confirm: function() {	
                $($this).closest("form").submit();
            },
            cancel: function() {	
                return false;
            }
        });	
    }
    
    function statusChange(msg, id, model)
    {
        $.confirm({
            text: msg,
            confirm: function() {	
                $.ajax({
                    url: APP_URL + "/admin/update_status",
                    type: "POST",
                    data: {
                        _token: _token,
                        id: id																																																																																																																																																																																																																																																																																								,
                        model: model
                    },
                    success: function (response) {
                        if(response.success)
                        {
                            $('#status-' + response.data.div_id).html(response.data.status);

                            if(response.data.status == 'Inactive'){
                                $('#status-action-' + response.data.div_id).html('Activate');
                                $('#status-action-' + response.data.div_id).removeClass('text-danger').addClass('text-success');
                                $('#status-' + response.data.div_id).removeClass('label-success').addClass('label-danger');
                            }else if(response.data.status == 'Active'){
                                $('#status-action-' + response.data.div_id).html('Deactivate');
                                $('#status-action-' + response.data.div_id).removeClass('text-success').addClass('text-danger');
                                $('#status-' + response.data.div_id).removeClass('label-danger').addClass('label-success');
                            }else if(response.data.status == 'Approve'){
                                $('#status-action-' + response.data.div_id).html('Reject');
                                $('#status-action-' + response.data.div_id).removeClass('text-primary').removeClass('text-success').addClass('text-danger');
                                $('#status-' + response.data.div_id).removeClass('label-primary').removeClass('label-danger').addClass('label-success');
                            }else if(response.data.status == 'Reject'){
                                $('#status-action-' + response.data.div_id).html('Approve');
                                $('#status-action-' + response.data.div_id).removeClass('text-danger').addClass('text-success');
                                $('#status-' + response.data.div_id).removeClass('label-success').addClass('label-danger');
                            }
                            
                            alertModel(response.message, 'success');
                        }
                        else
                        {
                            alertModel(response.message, 'error');
                        }
                    },
                    error: function (jqXhr, textStatus, errorMessage) {
                        alertModel("{{ __('messages.SomethingWentWrong') }}", 'error');
                    }
                });
            },
            cancel: function() {	
                return false;
            }
        });
    }
</script>
