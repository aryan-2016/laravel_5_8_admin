@php
    $requestSegments = Request::segments();
    $routeResource =  !empty($requestSegments[1]) ? $requestSegments[1] : '';    
    //$action = !empty($requestSegments[2]) ? $requestSegments[2] : '';
@endphp

<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu" data-widget="tree">
            <li class="{{ !empty($routeResource) && $routeResource == 'dashboard' ? 'active' : '' }}">
                <a href="{{ url('/admin/dashboard') }}">
                    <i class="fa fa-television"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li class="{{ !empty($routeResource) && $routeResource == 'users' ? 'active' : '' }}">
                <a href="{{ url('/admin/users') }}">
                    <i class="fa fa-users"></i>
                    <span>Manage Users</span>
                </a>
            </li>

            <li class="{{ !empty($routeResource) && $routeResource == 'categories' ? 'active' : '' }}">
                <a href="{{ url('/admin/categories') }}">
                    <i class="fa fa-clipboard"></i>
                    <span>Manage Categories</span>
                </a>
            </li>
            
            <li class="{{ !empty($routeResource) && $routeResource == 'cms-pages' ? 'active' : '' }}">
                <a href="{{ url('/admin/cms-pages') }}">
                    <i class="fa fa-file-text"></i>
                    <span>Manage CMS</span>
                </a>
            </li>
            
            <li class="{{ !empty($routeResource) && $routeResource == 'email-templates' ? 'active' : '' }}">
                <a href="{{ url('/admin/email-templates') }}">
                    <i class="fa fa-envelope-square"></i>
                    <span>Manage Email Templates</span>
                </a>
            </li>
            
            <li class="treeview {{ in_array($routeResource, ['global-settings', 'smtp-settings', 'mailing-addresses-settings']) ? 'active menu-open' : '' }}">
                <a href="javascript:void(0)">
                    <i class="fa fa-globe"></i>
                    <span>Manage Site Settings</span>
                    
                    <span class="pull-right-container">
                        <i class="fa fa-angle-right pull-right"></i>
                    </span>
                </a>
                
                <ul class="treeview-menu {{ in_array($routeResource, ['global-settings', 'smtp-settings', 'mailing-addresses-settings']) ? 'sidebar-menus' : '' }}">
                    <li class="{{ $routeResource == 'global-settings' ? 'active' : '' }}">
                        <a href="{{ url('/admin/global-settings') }}"><i class="fa fa-wrench"></i>Global Settings</a>
                    </li>
                    
                    <li class="{{ $routeResource == 'smtp-settings' ? 'active' : '' }}">
                        <a href="{{ url('/admin/smtp-settings') }}"><i class="fa fa-envelope"></i>SMTP Settings</a>
                    </li>
                    
                    <li class="{{ $routeResource == 'mailing-addresses-settings' ? 'active' : '' }}">
                        <a href="{{ url('/admin/mailing-addresses-settings') }}"><i class="fa fa-reply-all"></i>Mailing Addresses Settings</a>
                    </li>
                </ul>
            </li>
            
            
            <li class="treeview {{ in_array($routeResource, ['change-password', 'notification-settings']) ? 'active menu-open' : '' }}">
                <a href="javascript:void(0)">
                    <i class="fa fa-shield"></i>
                    <span>Manage Account Settings</span>
                    
                    <span class="pull-right-container">
                        <i class="fa fa-angle-right pull-right"></i>
                    </span>
                </a>
                
                <ul class="treeview-menu {{ in_array($routeResource, ['change-password']) ? 'sidebar-menus' : '' }}">
                    <li class="{{ $routeResource == 'change-password' ? 'active' : '' }}">
                        <a href="{{ url('/admin/change-password') }}"><i class="fa fa-unlock-alt"></i>Change Password</a>
                    </li>
                </ul>
            </li>
            
            <li>
                <a href="{{ url('/admin/logout') }}">
                    <i class="fa  fa-sign-out"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </section>
</aside>
