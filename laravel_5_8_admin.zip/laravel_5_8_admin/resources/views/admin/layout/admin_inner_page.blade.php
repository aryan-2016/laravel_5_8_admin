<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title>{{ config('SiteName') }}: Admin</title>
        
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        {{ Html::favicon( asset('/favicon.ico') ) }}
        
        <link href="{{ asset('/css/admin/bootstrap.min.css') }}" rel="stylesheet">	
        <link href="{{ asset('/css/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/admin.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/skins/skins.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/developer.css') }}" rel="stylesheet">
        
        <script src="{{ asset('/js/jquery.min.js') }}"></script>
        <script src="{{ asset('/js/admin/bootstrap.min.js') }}"></script>
        <script src="{{ asset('/js/admin/adminlte.min.js') }}"></script>
        <script src="{{ asset('/js/jquery.validate.js') }}"></script>
        
        <script>
            var APP_URL = "{{ config('app.url') }}";

            var _token = "{{ csrf_token() }}";
        </script>        
    </head>
    
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">    
            @include('admin.elements.common.header')
            
            @include('admin.elements.common.sidebar')
            
            @include('flash_message')
            
            @yield('content')            
            
            @include('admin.elements.common.footer')
        </div>
    </body>
</html>