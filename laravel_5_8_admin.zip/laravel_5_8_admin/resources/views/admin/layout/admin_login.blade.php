<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title>{{ config('SiteName') }}: Admin</title>
        
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <link href="{{ asset('/css/admin/bootstrap.min.css') }}" rel="stylesheet">	
        <link href="{{ asset('/css/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/admin.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/skins/skins.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/admin/developer.css') }}" rel="stylesheet">

        <script src="{{ asset('/js/jquery.min.js') }}"></script>
        <script src="{{ asset('/js/admin/bootstrap.min.js') }}"></script>
        <script src="{{ asset('/js/admin/adminlte.min.js') }}"></script>
        <script src="{{ asset('/js/jquery.validate.js') }}"></script>
    </head>
    <body class="hold-transition login-page">
        @yield('content')
    </body> 
</html>