@extends('admin.layout.admin_login')

@section('content')
    <div class="login-box">
        <div class="login-logo">          
            <a href="{{ url('/admin') }}">
                {{--{{ Html::image(asset('/public/images/common/logo.png'), 'logo image') }}--}}
                {{ config('SiteName') }}
            </a>            
        </div>

        <div class="login-box-body">
            <p class="login-box-msg">Sign in</p>
            
            @include('flash_message')
            
            {{ Form::open(array('class'=>'login-form', 'id'=>'loginForm', 'autocomplete' => 'off', 'method'=>'POST')) }}	
                <div class="form-group has-feedback">
                    {{ Form::text('email', null, array('class'=>'form-control email required', 'placeholder'=>'Email', 'autofocus')) }}
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
            
                <div class="form-group has-feedback">
                    {{ Form::password('password', array('class'=>'form-control required', 'placeholder'=>'Password')) }} 
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
            
                @if($displayRecaptcha)
                    <div class="form-group has-feedback">
                        <div class="g-recaptcha" data-sitekey="{{ CommonHelper::fetchGlobalSettingValueByName('GoogleRecaptchaSiteKey') }}"></div>
                        <span id="g-recaptcha-error" style="display:none;" for="g-recaptcha">{{ __('messages.VerifyCaptcha') }}</span>
                    </div>
                @endif
            
                <div class="row">
                    <div class="col-xs-12">
                        {{ Form::submit('Sign In', array('class'=>'btn btn-primary btn-block btn-flat', 'id'=>'loginBtn')) }} 
                    </div>
                </div>
            {{ Form::close() }}
            
            <a href="{{ url('/admin/forgot-password') }}">I forgot my password</a>
        </div>
    </div>

    <script src='https://www.google.com/recaptcha/api.js'></script>

    <script>
        $(function () {
            $("#loginForm").validate();

            @if($displayRecaptcha)
                $("#loginBtn").click( function(e){
                    var isCaptchaChecked = (grecaptcha && grecaptcha.getResponse().length !== 0);

                    if(!isCaptchaChecked)
                    {
                        e.preventDefault(e);
                        $('#g-recaptcha-error').show();
                    }
                });
            @endif
        });
    </script>	
@endsection