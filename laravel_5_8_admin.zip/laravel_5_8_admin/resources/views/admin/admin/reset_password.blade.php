@extends('admin.layout.admin_login')

@section('content')
    <div class="login-box">
        <div class="login-logo">          
            <a href="{{ url('/admin') }}">
                {{--{{ Html::image(asset('/public/images/common/logo.png'), 'logo image') }}--}}
                {{ config('SiteName') }}
            </a>            
        </div>

        <div class="login-box-body">
            <p class="login-box-msg">Reset Password</p>
            
            @include('flash_message')
            
            {{ Form::open(array('url'=>'admin/reset-password'.'?rpt='.$resetPasswordToken, 'class'=>'login-form', 'id'=>'resetPasswordForm', 'method'=>'POST')) }}	
                <div class="form-group">
                    {{ Form::password('password', ['placeholder'=>'Password', 'id'=>'password', 'class'=>'form-control required', 'minlength'=>'8', 'maxlength'=>'15']) }}
                </div>
            
                <div class="form-group">
                    {{ Form::password('password_confirmation', ['placeholder'=>'Confirm Password', 'id'=>'password_confirmation', 'class'=>'form-control required', 'data-rule-equalTo'=>'#password']) }}
                </div>
            
                <div class="row">
                    <div class="col-xs-12">
                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat', 'id'=>'loginBtn')) }} 
                    </div>
                </div>
            {{ Form::close() }}
            
            {{ Html::link(url('admin'), 'Back to Login', ['class'=>''], true)}}
        </div>
    </div>

    <script>
        $(function () {
            $("#resetPasswordForm").validate();
            
            /*$("#resetPasswordForm").validate({
                rules: {
                    password_confirmation: {equalTo: "#password"}
                },
                messages: {
                    password_confirmation: "{{ __('messages.Js.ConfirmPasswordError') }}"
                }
            });*/
        });
    </script>	
@endsection

