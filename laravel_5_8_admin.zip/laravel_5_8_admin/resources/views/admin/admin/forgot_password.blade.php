@extends('admin.layout.admin_login')

@section('content')
    <div class="login-box">
        <div class="login-logo">          
            <a href="{{ url('/admin') }}">
                {{--{{ Html::image(asset('/public/images/common/logo.png'), 'logo image') }}--}}
                {{ config('SiteName') }}
            </a>            
        </div>

        <div class="login-box-body">
            <p class="login-box-msg">Forgot Password</p>
            
            @include('flash_message')
            
            {{ Form::open(array('class'=>'login-form', 'id'=>'forgotPasswordForm', 'method'=>'POST')) }}	
                <div class="form-group has-feedback">
                    {{ Form::text('email', null, array('class'=>'form-control email required', 'placeholder' => 'Email', 'autofocus')) }}
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
            
                <div class="row">
                    <div class="col-xs-12">
                        {{ Form::submit('REQUEST RESET LINK', array('class'=>'btn btn-primary btn-block btn-flat', 'id'=>'loginBtn')) }} 
                    </div>
                </div>
            {{ Form::close() }}
            
            {{ Html::link(url('admin'), 'Back to Login', ['class'=>''], true)}}
        </div>
    </div>

    <script>
        $(function () {
            $("#forgotPasswordForm").validate();
        });
    </script>	
@endsection

