@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>
                        
                        @if(!empty($category))
                            {{ Form::model($category, array('route'=>array('categories.update', \Crypt::encryptString($category->id)), 'method'=>'PUT','id'=>'categoryForm')) }}
                        @else
                            {{ Form::open(array('url'=>'/admin/categories', 'id'=>'categoryForm')) }}
                        @endif
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Name</label>
                                            {{ Form::text('name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'255')) }}
                                        </div>
                                    </div>                                    
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            {{ Form::Select('status', $status, null, ['placeholder'=>' - select - ', 'class'=>'form-control required']) }}
                                        </div>
                                    </div>
                                </div>                         
                    
                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#categoryForm').validate();
        });
    </script>
@endsection