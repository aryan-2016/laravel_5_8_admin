@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box box-primary">
                        {{ Form::model($smtpSettings, array('route' => array('update-smtp-setting', \Crypt::encryptString(!empty($smtpSettings) ? $smtpSettings->id : '')), 'method' => 'POST', 'id'=>'smtpSettingForm')) }}
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Driver</label>
                                            {{ Form::text('driver', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Host</label>
                                            {{ Form::text('host', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191')) }}
                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Port</label>
                                            {{ Form::text('port', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>User Name</label>
                                            {{ Form::text('username', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191')) }}
                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Password</label>
                                            {{ Form::text('password', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Encryption</label>
                                            {{ Form::text('encryption', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div> 
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Mail From Email Address</label>
                                            {{ Form::text('mail_from_email_address', null, array('class'=>'form-control required email', 'minlength'=>'5', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Mail From Name</label>
                                            {{ Form::text('mail_from_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2 col-md-4">
                                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                    </div> 
                                </div>
                            </div>
                        {{ Form::close() }}                        
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#smtpSettingForm').validate();
        });
    </script>
@endsection