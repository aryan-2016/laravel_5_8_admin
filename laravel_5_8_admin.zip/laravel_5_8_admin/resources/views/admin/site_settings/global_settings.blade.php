@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>@sortablelink('name', 'Name')</th>                                        
                                        <th>Value</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    @if(count($globalSettings))                                    
                                        @foreach($globalSettings as $globalSetting)
                                            <tr id="{{ \Crypt::encryptString($globalSetting->id) }}">
                                                <td>{{ !empty($globalSetting->name) ? $globalSetting->name : \Config::get('constants.EmptyNotation') }}</td>                                                
                                                <td style='width:70%;'>
                                                    <span class="editSpan setting-value">{{ !empty($globalSetting->value) ? $globalSetting->value : \Config::get('constants.EmptyNotation') }}</span>
                                                    <input class="editInput setting-value" type="text" name="value" value="{{ $globalSetting->value }}" style="display: none;">
                                                </td>
                                                <td>
                                                    {!! Form::button('', array('type' => 'button', 'class' => 'pull-left fa fa-edit text-success editBtn', 'title' => 'Edit Global Setting')) !!}
                                                    {!! Form::button('', array('type' => 'button', 'class' => 'pull-left fa fa-floppy-o saveBtn', 'title' => 'Save Global Setting', 'style' => 'display: none;')) !!}
                                                </td>
                                            </tr>
                                        @endforeach                                    
                                    @else
                                        <tr><td colspan="4" class="error-msg">{{\Config::get('flash_msg.NoRecordFound')}}</td></tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.common.bootstrap_alert_model')

    <script>
        $(document).ready(function () {
            $('.editBtn').on('click',function(){
                //hide edit span
                $(this).closest("tr").find(".editSpan").hide();

                //show edit input
                $(this).closest("tr").find(".editInput").show().css({"width": "90%"});

                //hide edit button
                $(this).closest("tr").find(".editBtn").hide();

                //show save button
                $(this).closest("tr").find(".saveBtn").show();
            });
            
            $('.saveBtn').on('click',function(){
                var trObj = $(this).closest("tr");
                var ID = $(this).closest("tr").attr('id');
                var value = $(this).closest("tr").find(".editInput.setting-value").val();
                
                $.ajax({
                    type: 'POST',
                    url: APP_URL + "/admin/update-global-setting/" + ID,
                    dataType: "json",
                    data: {
                        _token: _token,
                        value: value
                    }
                })
                .done(function(response){
                    if(response.success){
                        trObj.find(".editSpan.setting-value").text(response.data.value);

                        trObj.find(".editInput.setting-value").text(response.data.value);

                        trObj.find(".editInput").hide();
                        trObj.find(".saveBtn").hide();
                        trObj.find(".editSpan").show();
                        trObj.find(".editBtn").show();

                        alertModel(response.message, 'success');
                    }
                    else{
                        alertModel(response.message, 'error');
                    }
                })
                .fail(function(jqXHR, textStatus) {
                    alertModel("{{ __('messages.SomethingWentWrong') }}", 'error');
                });
            });
        });
    </script>   
@endsection