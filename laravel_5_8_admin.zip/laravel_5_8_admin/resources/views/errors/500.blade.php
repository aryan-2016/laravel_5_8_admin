@extends('front.layouts.front')

@section('content')
    <section>
        <div class="bg-light">
            <div class="wrapper">
                <div class="breadcrumb_box">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/') }}">Home</a>
                        </li>
                    </ul>
                </div>
                
                <div class="clearfix"></div>
            </div>
          
            <div class="bg-white">
                <div class="wrapper text-center" style="padding:50px 0">
                    <h1 class="section-heading playfair-regular">
                        <span class="text-orange">Thats’s an error.</span>
                    </h1>
                    
                    <p>
                        Something went wrong, try again later!
                    </p>
                    
                    <div class="form-element btn-group" style="line-height:48px; margin:20px 0  0">
                        <!--<a href="javascript:void(0)" class="btn green-border-btn bg-transparent radius-2 rb-bold text-uppercase">Back</a>-->
                        
                        <a href="{{ url('/') }}" class="btn green-btn radius-2 rb-bold text-uppercase">Home</a>
                    </div>
               </div>
            </div>
        </div>
        
        <div class="clearfix"></div>
    </section>
@endsection
