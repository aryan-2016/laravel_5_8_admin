@component('mail::message')
    @component('mail::panel')
        {!! html_entity_decode($params['emailTemplate']['body']) !!}
    @endcomponent
@endcomponent