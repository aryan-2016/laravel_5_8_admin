<?php
return [
    //Start Js Msgs.
    'Js' => [
        'ConfirmDelete' => 'Are you sure you want to delete this record?',
        'ConfirmChangeStatus' => 'Are you sure you want to change status?',
        'FieldRequired' => 'This field is required.',
        'ConfirmPasswordError' => 'Password must be same.',
    ],
    //End Js Msgs.

    
    //Common Msgs
    'LoginInvalid' => 'Email and/or Password invalid!',
    'LogoutSuccess' => 'You have logout successfully!',
    
    'TryAgain' => 'Please try again!',
    'SomethingWentWrong' => 'Something went wrong, try again later!',
    
    'PasswordResetLinkSent' => 'Password reset link has been sent to your email address, Please check your mail inbox!',
    'EmailNotExist' => 'Email Address not exist!',
    
    'PasswordResetSuccess' => 'Password has been reset successfully!',
    'PasswordResetFail' => 'Password not resetted!',
    'PasswordResetInvalidLink' => 'Invalid password reset link!',
    'PasswordMustBeDifferent' => 'Your new password must be different from your current password!',
    
    'PasswordUpdated' => 'Password has been updated successfully!',
    'IncorrectInfo' => 'Please fill correct information!',
    
    'FileNotValid' => 'Uploaded file is not valid!',
    'ImageNotSaved' => 'Uploaded image not saved!',
    //'FileNotSaved' => 'Uploaded file not saved!',
    //'FileNotExist' => 'File does not exist!',
    'ImageSaved' => 'Uploaded image successfully saved!',
    
    'NoRecordFound' => 'Record not found!',
    
    'NotFound' => [
        'User' => 'User record not found!',
        'Farmer' => 'Farmer record not found!',    
        'Payment' => 'Payment record not found!',
        'Review' => 'Review record not found!',
        'Category' => 'Category record not found!',
        'Subscription' => 'Subscription record not found!',
        'Review' => 'Review record not found!',
        'Cms' => 'Cms Record not found!',
        'EmailTemplate' => 'Email template record not found!',
        'Farmer' => 'Farmer record not found!',
        'User' => 'User record not found!',
        'Report' => 'Report not found!',
        'Payment' => 'Payment record not found!',
        'ReportType' => 'Please select report type you want generate!',
        'Event' => 'Event record not found!',
        'Product' => 'Product record not found!',
        'OperationTime' => 'Operation Time record not found!',
    ],

    'NoResults' => 'Sorry, no results were found!',    
    //End Common Msgs.
    
    
    //Admin Msgs
    'WrongEmailId' => 'You have entered wrong email address!',
    
    'PasswordNotMatch' => 'Current password does not match!',
    'PasswordChanged' => 'Password has been changed successfully!',
    
    'NotificationSettingsUpdated' => 'Notification settings has been updated successfully!',
    
    'Cms' => [
        'Added' => 'CMS page successfully added!',
        'NotSaved' => 'CMS page could not saved!',    
        'Updated' => 'CMS page successfully updated!',   
        'NotUpdated' => 'CMS page could not be updated!',  
        'Deleted' => 'CMS page has been deleted successfully!'
    ],

    'User' => [
        'Added' => 'User Added successfully added!',
        'NotSaved' => 'User could not saved!',    
        'Updated' => 'User successfully updated!',   
        'NotUpdated' => 'User could not be updated!',  
        'Deleted' => 'User has been deleted successfully!',
        'NotDeleted' => 'User not deleted successfully!',
        'AssignedNotDeleted' => 'User can not be deleted as it is associated with existing records!',
    ],
    
    'Farmer' => [
        'Added' => 'Farmer Added successfully added!',
        'NotSaved' => 'Farmer could not saved!',    
        'Updated' => 'Farmer successfully updated!',   
        'NotUpdated' => 'Farmer could not be updated!',  
        'Deleted' => 'Farmer has been deleted successfully!',
        'NotDeleted' => 'Farmer not deleted successfully!',
        'AssignedNotDeleted' => 'Farmer can not be deleted as it is associated with existing records!',
    ],

    'Category' => [
        'Added' => 'Category page successfully added!',
        'NotSaved' => 'Category page could not saved!',    
        'Updated' => 'Category page successfully updated!',   
        'NotUpdated' => 'Category page could not be updated!',  
        'Deleted' => 'Category page has been deleted successfully!',
        'NotDeleted' => 'Category not deleted!',
        'AssignedNotDeleted' => 'Category can not be deleted as it is associated with existing records!',
    ],

    'Subscription' => [
        'Updated' => 'Subscription successfully updated!',   
        'NotUpdated' => 'Subscription could not be updated!',  
    ],
    
    'GlobalSetting' => [
        'Updated' => 'Global Setting successfully updated!',
        'NotUpdated' => 'Global Setting could not be updated!'
    ],
    
    'SmtpSetting' => [
        'Added' => 'Smtp Setting successfully added!',
        'Updated' => 'Smtp Setting successfully updated!',
        'NotSaved' => 'Smtp Setting could not be saved!'
    ],
    
    'MailingAddressesSetting' => [
        'Added' => 'Mailing Addresses Setting successfully added!',
        'Updated' => 'Mailing Addresses Setting successfully updated!',
        'NotSaved' => 'Mailing Addresses Setting could not be saved!'
    ],
    
    'EmailTemplate' => [
        'Added' => 'Email Template successfully added!',
        'Updated' => 'Email Template successfully updated!',
        'Deleted' => 'Email Template successfully deleted!',
        'NotSaved' => 'Email Template not saved!',
        'NotUpdated' => 'Email Template not updated!',
    ],   
    
    'VerifyCaptcha' => 'Please verify captcha first!',

    'StatusUpdated' => 'Status updated successfully!',
    'StatusNotUpdated' => 'Status not updated!',
    //End Admin Msgs    
];
